# Program Name: Sprin1_implementation 
# Course: IT3883/Section W02
# Student Name: Leonardo Barranco
# Assignment Number: Final
# Due Date: 5/3/2025
# Purpose: Create a code that recieves a quantity and name of coins and converts it to the numberical dollar
#https://www.geeksforgeeks.org/python-dictionary/
#https://www.geeksforgeeks.org/python-spilt-a-sentence-into-list-of-words/

#dicitionary to map out the coin names
coin_values = {
    "penny": 0.01,
    "pennies": 0.01,
    "nickel": 0.05,
    "nickels": 0.05,
    "dime": 0.10,
    "dimes": 0.10,
    "quarter": 0.25,
    "quarters": 0.25
}
def coin_total(sentence):
    words = sentence.strip().split() #this splits the sentence into words
    total = 0.0
    i = 0

    #Goes through the sentence checking if it is a number or a word in the dictionary and then multipies them together
    while i < len(words):
        if words[i].isdigit():
            quantity = int(words[i])
            if i+1<len(words):
                denomination = words[i+1]
                if denomination in coin_values:
                    total += quantity * coin_values[denomination]
            i +=2
        else:
            i+=1
    return round(total,2)

sentence = input("Enter the coin statement: ")
amount = coin_total(sentence)
print(f"{amount:.2f}")